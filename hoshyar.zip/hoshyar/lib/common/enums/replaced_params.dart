enum ReplacedParams {
  userName('{name}');

  final String param;
  const ReplacedParams(this.param);
}
