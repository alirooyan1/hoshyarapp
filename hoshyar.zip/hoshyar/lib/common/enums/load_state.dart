enum FSLoadState {
  refreshing,
  loading,
  loaded,
  noData,
  noMoreData,
}
