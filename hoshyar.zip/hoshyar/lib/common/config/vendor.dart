part of '../config.dart';

/// Everything Config about the Vendor Setting

/// Setting for Vendor Feature
VendorConfig get kVendorConfig => Configurations.vendorConfig;
