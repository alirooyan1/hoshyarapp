part of '../config.dart';

/// Everything Config about the Blog Setting

Map get kBlogDetail => Configurations.blogDetail;
