part of '../config.dart';

/// the welcome screen data
OnBoardingConfig get kOnBoardingConfig =>
    OnBoardingConfig.fromJson(Configurations.onBoardingConfig);
List get vendorOnBoarding => Configurations.vendorOnBoardingData;
