part of '../config.dart';

WishListConfig get kWishListConfig =>
    WishListConfig.fromJson(Configurations.wishListConfig);
