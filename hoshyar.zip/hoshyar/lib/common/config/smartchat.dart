part of '../config.dart';

ConfigChat get kConfigChat => Configurations.configChat;

/// config for the chat app
/// config Whatapp: https://faq.whatsapp.com/en/iphone/23559013
List<Map> get kListSmartChat => Configurations.smartChat;
