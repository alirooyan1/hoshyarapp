// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'judge_service_config.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$JudgeServiceConfigImpl _$$JudgeServiceConfigImplFromJson(
        Map<String, dynamic> json) =>
    _$JudgeServiceConfigImpl(
      domain: json['domain'] as String? ?? '',
      apiKey: json['apiKey'] as String? ?? '',
    );

Map<String, dynamic> _$$JudgeServiceConfigImplToJson(
        _$JudgeServiceConfigImpl instance) =>
    <String, dynamic>{
      'domain': instance.domain,
      'apiKey': instance.apiKey,
    };
