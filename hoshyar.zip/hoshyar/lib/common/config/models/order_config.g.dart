// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'order_config.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$OrderConfigImpl _$$OrderConfigImplFromJson(Map<String, dynamic> json) =>
    _$OrderConfigImpl(
      version: (json['version'] as num?)?.toInt() ?? 1,
    );

Map<String, dynamic> _$$OrderConfigImplToJson(_$OrderConfigImpl instance) =>
    <String, dynamic>{
      'version': instance.version,
    };
