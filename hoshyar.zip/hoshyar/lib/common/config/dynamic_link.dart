part of '../config.dart';

DynamicLinkConfig get dynamicLinkConfig => Configurations.dynamicLinkConfig;
