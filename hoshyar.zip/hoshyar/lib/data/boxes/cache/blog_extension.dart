part of '../../boxes.dart';

extension BlogCacheExtension on CacheBox {}
