part of '../../../boxes.dart';

mixin EncryptionMixin on FluxBox {
  @override
  bool get isEncrypted => true;
}
