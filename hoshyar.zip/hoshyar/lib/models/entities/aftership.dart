class AfterShipTracking {
  final String? slug;
  final String? trackingNumber;

  const AfterShipTracking(this.trackingNumber, this.slug);
}
