import 'advertisement_item.dart';

class AdvertisementView {
  bool active;
  AdvertisementItem? data;

  AdvertisementView({
    this.active = false,
    this.data,
  });
}
