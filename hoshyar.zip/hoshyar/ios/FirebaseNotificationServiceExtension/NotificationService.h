//
//  NotificationService.h
//  FirebaseNotificationServiceExtension
//
//  Created by InspireUI on 10/1/25.
//  Copyright © 2025 The Chromium Authors. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
